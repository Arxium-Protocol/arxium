use rocksdb::{ColumnFamily, ColumnFamilyDescriptor, DB, Direction, IteratorMode, Options as RocksOptions, WriteBatch};
use serde::Serialize;
use serde::de::DeserializeOwned;
use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;
use thiserror::Error;
use xc_primitives::{AccountEntry, Address, Block, Snapshot, StakeAllocation};
#[cfg(test)]
use xc_primitives::Action;

// ponytail: cap shared by range/history reads so an explorer client can't
// force a full-chain scan in one request; bump if a real UI needs more.
pub const MAX_PAGE_SIZE: usize = 100;

#[derive(Error, Debug)]
pub enum StorageError {
    #[error("RocksDB underlying error: {0}")]
    Rocks(#[from] rocksdb::Error),

    #[error("encode error: {0}")]
    Encode(#[from] bincode::error::EncodeError),

    #[error("decode error: {0}")]
    Decode(#[from] bincode::error::DecodeError),

    #[error("corrupted metadata value in storage")]
    CorruptedMeta,
}

const CF_META: &str = "meta";
const CF_BLOCKS: &str = "blocks";
const CF_ACCOUNTS: &str = "accounts";
const CF_VALIDATORS: &str = "validators";
const COLUMN_FAMILIES: [&str; 4] = [CF_META, CF_BLOCKS, CF_ACCOUNTS, CF_VALIDATORS];

/// Which column family a key belongs in, derived from its prefix rather than
/// tracked separately at each call site — one place to keep in sync with the
/// `format!("prefix:...")` calls below instead of every `get`/`put` call
/// needing its own CF argument.
fn cf_for_key(key: &[u8]) -> &'static str {
    if key.starts_with(b"account:") {
        CF_ACCOUNTS
    } else if key.starts_with(b"block:") || key.starts_with(b"block_hash:") || key.starts_with(b"action:") {
        CF_BLOCKS
    } else if key.starts_with(b"validator") || key.starts_with(b"stake") {
        CF_VALIDATORS
    } else {
        CF_META
    }
}

#[derive(Clone)]
pub struct ArxiumDb {
    db: Arc<DB>,
}

/// Anything that can be turned into a set of key-value pairs for storage.
pub trait BatchWritable {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError>;

    /// Keys to remove as part of the same atomic batch. Default empty —
    /// most `BatchWritable`s (accounts, blocks, ...) only ever upsert.
    fn batch_deletes(&self) -> Result<Vec<Vec<u8>>, StorageError> {
        Ok(Vec::new())
    }
}

impl ArxiumDb {
    pub fn open(path: &Path) -> Result<Self, StorageError> {
        let mut db_opts = RocksOptions::default();
        db_opts.create_if_missing(true);
        db_opts.create_missing_column_families(true);
        let cf_descriptors = COLUMN_FAMILIES
            .iter()
            .map(|name| ColumnFamilyDescriptor::new(*name, RocksOptions::default()));
        let db = DB::open_cf_descriptors(&db_opts, path, cf_descriptors)?;
        Ok(Self { db: Arc::new(db) })
    }

    /// Column family handle for `name` — always present since `open` creates
    /// all of `COLUMN_FAMILIES` up front.
    fn cf(&self, name: &str) -> &ColumnFamily {
        self.db.cf_handle(name).expect("column family created in ArxiumDb::open")
    }

    pub fn get(&self, key: &[u8]) -> Result<Option<Vec<u8>>, StorageError> {
        self.db.get_cf(self.cf(cf_for_key(key)), key).map_err(StorageError::Rocks)
    }

    /// Get the current tip height from the DB.
    pub fn get_tip_height(&self) -> Result<Option<u64>, StorageError> {
        match self.get(b"meta:tip_height")? {
            Some(bytes) => {
                let arr: [u8; 8] = bytes.try_into().map_err(|_| StorageError::CorruptedMeta)?;
                Ok(Some(u64::from_be_bytes(arr)))
            }
            None => Ok(None),
        }
    }

    /// Check if the database has been initialized
    pub fn is_initialized(&self) -> Result<bool, StorageError> {
        Ok(self.get(b"meta:height")?.is_some())
    }

    /// Get the chain name recorded at genesis.
    pub fn get_chain_name(&self) -> Result<Option<String>, StorageError> {
        match self.get(b"meta:chain_name")? {
            Some(bytes) => {
                String::from_utf8(bytes).map(Some).map_err(|_| StorageError::CorruptedMeta)
            }
            None => Ok(None),
        }
    }

    /// Write any batch-writable item's entries atomically.
    pub fn write_batch(&self, item: &impl BatchWritable) -> Result<(), StorageError> {
        self.write_batches(&[item as &dyn BatchWritable])
    }

    /// Write several batch-writable items' entries as a single atomic write.
    /// Use this when two items must land together or not at all — e.g. a
    /// block record and the account changes it caused, so a crash can never
    /// leave one committed without the other.
    pub fn write_batches(&self, items: &[&dyn BatchWritable]) -> Result<(), StorageError> {
        let mut batch = WriteBatch::default();
        for item in items {
            for (key, value) in item.batch_entries()? {
                batch.put_cf(self.cf(cf_for_key(&key)), key, value);
            }
            for key in item.batch_deletes()? {
                batch.delete_cf(self.cf(cf_for_key(&key)), key);
            }
        }
        // Fsync every commit rather than trusting the OS page cache — this
        // chain produces one batch per block on a multi-second interval, not
        // per-transaction, so the extra fsync latency is cheap insurance
        // against a hard crash leaving the on-disk tip ahead of durable data
        // (which would violate the "tip block must exist" invariant on
        // restart, see arxd/node/src/produce.rs).
        let mut opts = rocksdb::WriteOptions::default();
        opts.set_sync(true);
        self.db.write_opt(batch, &opts)?;
        Ok(())
    }

    /// Get the account state from the DB
    pub fn get_account(&self, address: &Address) -> Result<Option<AccountEntry>, StorageError> {
        let key = format!("account:{}", address);
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let config = bincode::config::standard();
                let (account, _len) = bincode::serde::decode_from_slice(&bytes, config)?;
                Ok(Some(account))
            }
            None => Ok(None),
        }
    }

    /// Get the block from the DB. `P` is the chain-specific action payload
    /// type — callers know it, storage doesn't.
    pub fn get_block<P: DeserializeOwned>(&self, height: u64) -> Result<Option<Block<P>>, StorageError> {
        let key = format!("block:{height:020}");
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let config = bincode::config::standard();
                let (block, _len) = bincode::serde::decode_from_slice(&bytes, config)?;
                Ok(Some(block))
            }
            None => Ok(None),
        }
    }

    /// Look up the height of the block containing a confirmed action, by signature.
    pub fn get_action_block_height(&self, signature: &str) -> Result<Option<u64>, StorageError> {
        let key = format!("action:{}", signature);
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let arr: [u8; 8] = bytes.try_into().map_err(|_| StorageError::CorruptedMeta)?;
                Ok(Some(u64::from_be_bytes(arr)))
            }
            None => Ok(None),
        }
    }

    /// Fetch blocks `from..=to` (inclusive), capped at `MAX_PAGE_SIZE`.
    /// Heights are committed sequentially with no gaps (single proposer, no
    /// forks), so this is a plain per-height point lookup, not a scan.
    pub fn get_block_range<P: DeserializeOwned>(
        &self,
        from: u64,
        to: u64,
    ) -> Result<Vec<Block<P>>, StorageError> {
        let to = to.min(from.saturating_add(MAX_PAGE_SIZE as u64 - 1));
        let mut blocks = Vec::new();
        for height in from..=to {
            if let Some(block) = self.get_block(height)? {
                blocks.push(block);
            }
        }
        Ok(blocks)
    }

    /// The round-robin validator set effective as of `height` — the latest
    /// `ValidatorSetSnapshot` recorded at or before `height`. A change
    /// applied in block `H` is recorded effective at `H + 1` (see
    /// `ValidatorSetSnapshot`), so a block's own proposer check always sees
    /// the set as it stood before that block, never one it could vote itself
    /// into. Falls back to an empty set only if genesis never wrote height 0
    /// (shouldn't happen on a bootstrapped chain).
    pub fn get_validator_set_at(&self, height: u64) -> Result<Vec<Address>, StorageError> {
        let prefix = b"validator_set:";
        let seek_key = format!("validator_set:{height:020}");
        let iter = self
            .db
            .iterator_cf(self.cf(CF_VALIDATORS), IteratorMode::From(seek_key.as_bytes(), Direction::Reverse));
        for item in iter {
            let (key, value) = item?;
            if !key.starts_with(prefix) {
                break;
            }
            let config = bincode::config::standard();
            let (validators, _len) = bincode::serde::decode_from_slice(&value, config)?;
            return Ok(validators);
        }
        Ok(Vec::new())
    }

    /// Look up a block's height by its content hash.
    pub fn get_block_height_by_hash(&self, hash: &str) -> Result<Option<u64>, StorageError> {
        let key = format!("block_hash:{}", hash);
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let arr: [u8; 8] = bytes.try_into().map_err(|_| StorageError::CorruptedMeta)?;
                Ok(Some(u64::from_be_bytes(arr)))
            }
            None => Ok(None),
        }
    }

    /// A single `(master, validator)` stake allocation, if any.
    pub fn get_stake_allocation(
        &self,
        master: &Address,
        validator: &Address,
    ) -> Result<Option<StakeAllocation>, StorageError> {
        let key = format!("stake:{}:{}", master, validator);
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let config = bincode::config::standard();
                let (allocation, _len) = bincode::serde::decode_from_slice(&bytes, config)?;
                Ok(Some(allocation))
            }
            None => Ok(None),
        }
    }

    /// Masters currently staking to `validator`. One-master-per-validator is
    /// an enforced invariant, not just an assumption — callers should treat
    /// a `len() > 1` result as a bug, not a valid multi-delegator state.
    pub fn get_stakes_by_validator(&self, validator: &Address) -> Result<Vec<Address>, StorageError> {
        let key = format!("stake_by_validator:{}", validator);
        match self.get(key.as_bytes())? {
            Some(bytes) => {
                let config = bincode::config::standard();
                let (masters, _len) = bincode::serde::decode_from_slice(&bytes, config)?;
                Ok(masters)
            }
            None => Ok(Vec::new()),
        }
    }

    /// All of `master`'s stake allocations, one per validator staked to.
    pub fn get_stakes_by_master(
        &self,
        master: &Address,
    ) -> Result<Vec<(Address, StakeAllocation)>, StorageError> {
        let prefix = format!("stake:{}:", master);
        let mut results = Vec::new();
        let iter = self
            .db
            .iterator_cf(self.cf(CF_VALIDATORS), IteratorMode::From(prefix.as_bytes(), Direction::Forward));
        for item in iter {
            let (key, value) = item?;
            if !key.starts_with(prefix.as_bytes()) {
                break;
            }
            let validator_str = std::str::from_utf8(&key[prefix.len()..])
                .map_err(|_| StorageError::CorruptedMeta)?;
            let validator = Address::parse(validator_str).map_err(|_| StorageError::CorruptedMeta)?;
            let config = bincode::config::standard();
            let (allocation, _len) = bincode::serde::decode_from_slice(&value, config)?;
            results.push((validator, allocation));
        }
        Ok(results)
    }

    /// Every allocation with an `Unbonding` batch matured as of `height`.
    // ponytail: full `stake:` prefix scan — fine at current scale (matches
    // the doc's "walking skeleton" allowance); add an unlock-height
    // secondary index if allocation count ever makes this a bottleneck.
    pub fn get_allocations_with_unbonding_due(
        &self,
        height: u64,
    ) -> Result<Vec<StakeAllocation>, StorageError> {
        let prefix = b"stake:";
        let mut results = Vec::new();
        let iter = self
            .db
            .iterator_cf(self.cf(CF_VALIDATORS), IteratorMode::From(prefix, Direction::Forward));
        for item in iter {
            let (key, value) = item?;
            if !key.starts_with(prefix) {
                break;
            }
            let config = bincode::config::standard();
            let (allocation, _len): (StakeAllocation, usize) =
                bincode::serde::decode_from_slice(&value, config)?;
            if let Some(unbonding) = &allocation.unbonding {
                if unbonding.unlock_at_height <= height {
                    results.push(allocation);
                }
            }
        }
        Ok(results)
    }
}

impl BatchWritable for Snapshot {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError> {
        let config = bincode::config::standard();
        let mut entries = vec![
            (b"meta:height".to_vec(), self.height.to_be_bytes().to_vec()),
            (
                b"meta:chain_name".to_vec(),
                self.chain_name.as_bytes().to_vec(),
            ),
        ];
        for (address, account) in &self.accounts {
            let key = format!("account:{}", address).into_bytes();
            let value = bincode::serde::encode_to_vec(account, config)?;
            entries.push((key, value));
        }
        for (address, validator) in &self.validators {
            let key = format!("validator:{}", address).into_bytes();
            let value = bincode::serde::encode_to_vec(validator, config)?;
            entries.push((key, value));
        }
        let mut genesis_validators: Vec<Address> = self.validators.keys().cloned().collect();
        genesis_validators.sort();
        entries.push((
            b"validator_set:00000000000000000000".to_vec(),
            bincode::serde::encode_to_vec(&genesis_validators, config)?,
        ));
        Ok(entries)
    }
}

/// The round-robin validator set effective starting `effective_height`,
/// written by `xc_executor::accept_block`/`produce_block` whenever a block
/// contains a `ValidatorChange` — one full-set snapshot per change, looked up
/// via `ArxiumDb::get_validator_set_at`. `effective_height` is the changing
/// block's height + 1: the change can't affect who proposes the block that
/// introduced it.
pub struct ValidatorSetSnapshot {
    pub effective_height: u64,
    pub validators: Vec<Address>,
}

impl BatchWritable for ValidatorSetSnapshot {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError> {
        let config = bincode::config::standard();
        let mut sorted = self.validators.clone();
        sorted.sort();
        Ok(vec![(
            format!("validator_set:{:020}", self.effective_height).into_bytes(),
            bincode::serde::encode_to_vec(&sorted, config)?,
        )])
    }
}

impl<P: Serialize> BatchWritable for Block<P> {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError> {
        let config = bincode::config::standard();

        let block_key = format!("block:{:020}", self.height).into_bytes();
        let block_value = bincode::serde::encode_to_vec(self, config)?;

        let mut entries = vec![
            (block_key, block_value),
            (
                b"meta:tip_height".to_vec(),
                self.height.to_be_bytes().to_vec(),
            ),
            (
                format!("block_hash:{}", self.hash()).into_bytes(),
                self.height.to_be_bytes().to_vec(),
            ),
        ];

        for action in self.actions.iter() {
            if let Some(signature) = &action.signature {
                entries.push((
                    format!("action:{}", signature).into_bytes(),
                    self.height.to_be_bytes().to_vec(),
                ));
            }
        }

        Ok(entries)
    }
}

/// A set of account changes to be written atomically. Not account-circuit
/// business logic — just the write-batch shape any circuit that touches
/// accounts (`circuit-account`, `circuit-rwa-asset`, ...) hands back.
#[derive(Debug, Default)]
pub struct AccountUpdates(pub HashMap<Address, AccountEntry>);

impl BatchWritable for AccountUpdates {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError> {
        let config = bincode::config::standard();
        let mut entries = Vec::new();
        for (address, entry) in &self.0 {
            let key = format!("account:{}", address).into_bytes();
            let value = bincode::serde::encode_to_vec(entry, config)?;
            entries.push((key, value));
        }
        Ok(entries)
    }
}

/// A set of stake-allocation changes to be written atomically alongside a
/// block, same reasoning as `AccountUpdates`. `allocations` maps
/// `(master, validator) -> Some(allocation)` for an upsert or `None` for a
/// removal (fully slashed / fully resolved). `validator_index` maps
/// `validator -> full new master list` for that validator's
/// `stake_by_validator:` row — an empty list removes the row.
#[derive(Debug, Default)]
pub struct StakeUpdates {
    pub allocations: std::collections::BTreeMap<(Address, Address), Option<StakeAllocation>>,
    pub validator_index: std::collections::BTreeMap<Address, Vec<Address>>,
}

impl BatchWritable for StakeUpdates {
    fn batch_entries(&self) -> Result<Vec<(Vec<u8>, Vec<u8>)>, StorageError> {
        let config = bincode::config::standard();
        let mut entries = Vec::new();
        for ((master, validator), allocation) in &self.allocations {
            if let Some(allocation) = allocation {
                let key = format!("stake:{}:{}", master, validator).into_bytes();
                let value = bincode::serde::encode_to_vec(allocation, config)?;
                entries.push((key, value));
            }
        }
        for (validator, masters) in &self.validator_index {
            if !masters.is_empty() {
                let key = format!("stake_by_validator:{}", validator).into_bytes();
                let value = bincode::serde::encode_to_vec(masters, config)?;
                entries.push((key, value));
            }
        }
        Ok(entries)
    }

    fn batch_deletes(&self) -> Result<Vec<Vec<u8>>, StorageError> {
        let mut deletes = Vec::new();
        for ((master, validator), allocation) in &self.allocations {
            if allocation.is_none() {
                deletes.push(format!("stake:{}:{}", master, validator).into_bytes());
            }
        }
        for (validator, masters) in &self.validator_index {
            if masters.is_empty() {
                deletes.push(format!("stake_by_validator:{}", validator).into_bytes());
            }
        }
        Ok(deletes)
    }
}

#[cfg(test)]
mod explorer_index_tests {
    use super::*;

    fn temp_db() -> ArxiumDb {
        let path = std::env::temp_dir().join(format!("arxium-test-storage-{}", uuid_like()));
        ArxiumDb::open(&path).unwrap()
    }

    fn uuid_like() -> u128 {
        use std::sync::atomic::{AtomicU64, Ordering};
        static COUNTER: AtomicU64 = AtomicU64::new(0);
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        nanos + COUNTER.fetch_add(1, Ordering::Relaxed) as u128
    }

    fn addr(byte: u8) -> Address {
        Address::from_pubkey_bytes(&[byte; 32]).unwrap()
    }

    fn action(sender: Address, nonce: u64) -> Action<()> {
        Action {
            sender,
            nonce,
            signature: Some(format!("sig-{}", nonce)),
            payload: (),
        }
    }

    fn block(height: u64, actions: Vec<Action<()>>) -> Block<()> {
        Block {
            height,
            parent_hash: "0xparent".into(),
            timestamp: height,
            actions,
            proposer: None,
            signature: None,
        }
    }

    #[test]
    fn block_range_fetches_committed_span() {
        let db = temp_db();
        for h in 0..5 {
            db.write_batch(&block(h, vec![])).unwrap();
        }
        let blocks = db.get_block_range::<()>(1, 3).unwrap();
        assert_eq!(
            blocks.iter().map(|b| b.height).collect::<Vec<_>>(),
            vec![1, 2, 3]
        );
    }

    #[test]
    fn block_hash_round_trips_to_height() {
        let db = temp_db();
        let b = block(7, vec![]);
        let hash = b.hash();
        db.write_batch(&b).unwrap();
        assert_eq!(db.get_block_height_by_hash(&hash).unwrap(), Some(7));
        assert_eq!(db.get_block_height_by_hash("0xnope").unwrap(), None);
    }

    #[test]
    fn validator_set_at_returns_latest_snapshot_at_or_before_height() {
        let db = temp_db();
        db.write_batch(&ValidatorSetSnapshot {
            effective_height: 0,
            validators: vec![addr(1)],
        })
        .unwrap();
        db.write_batch(&ValidatorSetSnapshot {
            effective_height: 5,
            validators: vec![addr(1), addr(2)],
        })
        .unwrap();
        let mut expected_pair = vec![addr(1), addr(2)];
        expected_pair.sort();

        assert_eq!(db.get_validator_set_at(0).unwrap(), vec![addr(1)]);
        assert_eq!(db.get_validator_set_at(4).unwrap(), vec![addr(1)]);
        assert_eq!(db.get_validator_set_at(5).unwrap(), expected_pair);
        assert_eq!(db.get_validator_set_at(100).unwrap(), expected_pair);
    }
}
